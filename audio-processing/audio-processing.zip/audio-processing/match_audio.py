from pymongo import MongoClient
from utils import fingerprint_audio
from collections import defaultdict
import sys

def match_audio(file_path):
    client = MongoClient("mongodb://localhost:27017/")
    db = client["audiora"]
    collection = db["fingerprints"]

    input_hashes = fingerprint_audio(file_path)
    hash_map = defaultdict(list)

    for h in input_hashes:
        hash_map[h["hash"]].append(h["offset"])

    candidates = []

    for song in collection.find():
        match_offsets = []
        song_hashes = song["hashes"]

        for h in song_hashes:
            if h["hash"] in hash_map:
                for user_offset in hash_map[h["hash"]]:
                    delta = round(user_offset - h["offset"], 2)
                    match_offsets.append(delta)

        if match_offsets:
            most_common_offset = max(set(match_offsets), key=match_offsets.count)
            score = match_offsets.count(most_common_offset)
            candidates.append((song["song_name"], song["url"], score))

    if not candidates:
        print("❌ No match found.")
        return

    best_match = max(candidates, key=lambda x: x[2])
    print(f"✅ Best Match: {best_match[0]}")
    print(f"🔗 URL: {best_match[1]}")
    print(f"🎯 Confidence Score: {best_match[2]} matches")

if __name__ == "__main__":
    if len(sys.argv) < 2:
        print("Usage: python match_audio.py <audio_file.wav>")
    else:
        match_audio(sys.argv[1])
