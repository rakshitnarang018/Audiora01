import numpy as np
from pydub import AudioSegment
from scipy.io import wavfile
from scipy.fftpack import fft

def convert_mp3_to_wav(mp3_path):
    audio = AudioSegment.from_mp3(mp3_path)
    audio = audio.set_channels(1).set_frame_rate(44100)
    wav_path = mp3_path.replace(".mp3pip", ".wav")
    audio.export(wav_path, format="wav")
    return wav_path

def fingerprint_audio(wav_path):
    rate, data = wavfile.read(wav_path)
    if len(data.shape) == 2:
        data = data[:, 0]  # convert stereo to mono

    frame_size = 4096
    step_size = 2048
    hashes = []

    for i in range(0, len(data) - frame_size, step_size):
        frame = data[i:i + frame_size]
        fft_result = np.abs(fft(frame))
        freqs = fft_result[:frame_size // 2]

        peak = np.argmax(freqs)  # peak frequency bin index
        # Create a hash from the peak frequency (simple example)
        hash_val = int(peak)
        hashes.append(hash_val)

    return hashes
