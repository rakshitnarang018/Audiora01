import os
import numpy as np
import scipy.signal
import matplotlib.pyplot as plt
from pydub import AudioSegment
from pytube import YouTube
from pymongo import MongoClient
from scipy.io import wavfile
import hashlib

# Connect to MongoDB
client = MongoClient("mongodb://localhost:27017/")
db = client["audiora"]
collection = db["fingerprints"]

# Songs
YOUTUBE_SONGS = [
    {"name": "Shape of You", "url": "https://www.youtube.com/watch?v=JGwWNGJdvx8"},
    {"name": "Blinding Lights", "url": "https://www.youtube.com/watch?v=4NRXx6U8ABQ"},
    {"name": "Counting Stars", "url": "https://www.youtube.com/watch?v=hT_nvWreIhg"},
    {"name": "Faded", "url": "https://www.youtube.com/watch?v=60ItHLz5WEA"},
    {"name": "Sugar", "url": "https://www.youtube.com/watch?v=09R8_2nJtjg"},
    {"name": "Senorita", "url": "https://www.youtube.com/watch?v=Pkh8UtuejGw"},
    {"name": "Perfect", "url": "https://www.youtube.com/watch?v=2Vv-BfVoq4g"},
    {"name": "Let Her Go", "url": "https://www.youtube.com/watch?v=RBumgq5yVrA"},
    {"name": "Someone You Loved", "url": "https://www.youtube.com/watch?v=bCuhuePlP8o"},
    {"name": "Girls Like You", "url": "https://www.youtube.com/watch?v=aJOTlE1K90k"},
]

def download_audio(song_name, url):
    yt = YouTube(url)
    stream = yt.streams.filter(only_audio=True).first()
    out_file = stream.download(filename=f"{song_name}.mp4")
    audio = AudioSegment.from_file(out_file)
    audio = audio.set_channels(1).set_frame_rate(44100)
    wav_file = f"{song_name}.wav"
    audio.export(wav_file, format="wav")
    os.remove(out_file)
    return wav_file

def fingerprint_audio(file_path):
    rate, data = wavfile.read(file_path)
    data = data.astype(np.float32)
    if data.ndim > 1:
        data = data.mean(axis=1)

    f, t, Sxx = scipy.signal.spectrogram(data, fs=rate, nperseg=2048, noverlap=1024)
    Sxx_log = 10 * np.log10(Sxx + 1e-10)

    # Peak picking
    peaks = []
    for i in range(Sxx_log.shape[1]):
        col = Sxx_log[:, i]
        peak_indices, _ = scipy.signal.find_peaks(col, height=np.max(col) - 10)
        for freq_idx in peak_indices:
            peaks.append((f[freq_idx], t[i]))

    # Hashing
    hashes = []
    fan_value = 5
    for i in range(len(peaks)):
        for j in range(1, fan_value):
            if (i + j) < len(peaks):
                freq1, t1 = peaks[i]
                freq2, t2 = peaks[i + j]
                if 0 < t2 - t1 <= 10:
                    h = hashlib.sha1(f"{int(freq1)}|{int(freq2)}|{round(t2 - t1, 2)}".encode()).hexdigest()[0:20]
                    hashes.append({
                        "hash": h,
                        "offset": round(t1, 2)
                    })
    return hashes
print(f"Generated {len(hashes)} hashes for {name}")

def store_in_db(song_name, url, hashes):
    collection.insert_one({
        "song_name": song_name,
        "url": url,
        "hashes": hashes
    })

# Main
for song in YOUTUBE_SONGS:
    name, url = song["name"], song["url"]
    print(f"Processing {name}")
    wav_file = download_audio(name, url)
    hashes = fingerprint_audio(wav_file)
    store_in_db(name, url, hashes)
    os.remove(wav_file)

print("✅ Fingerprints stored for all songs.")
