import json
import hashlib
import os
from pydub import AudioSegment
from utils import fingerprint_audio
from pymongo import MongoClient

def generate_fingerprint_json(audio_path):
    if not os.path.exists(audio_path):
        raise FileNotFoundError(f"{audio_path} not found.")

    song_name = os.path.basename(audio_path)
    audio = AudioSegment.from_file(audio_path)
    duration = round(len(audio) / 1000, 2)  # seconds

    hashes = fingerprint_audio(audio_path)  # List[int]

    # Convert list of ints to a single SHA-256 hex string
    hashes_str = ",".join(map(str, hashes))
    fingerprint_hash = hashlib.sha256(hashes_str.encode()).hexdigest()

    result = {
        "song_name": song_name,
        "fingerprint": fingerprint_hash,
        "duration": duration
    }

    print(json.dumps(result, indent=4))

    with open("fingerprint.json", "w") as f:
        json.dump(result, f, indent=4)

    # Insert or update in MongoDB
    client = MongoClient("mongodb://localhost:27017")
    db = client["audiodb"]
    collection = db["fingerprints"]

    collection.update_one(
        {"song_name": song_name},
        {"$set": result},
        upsert=True
    )
    print(f"Inserted/Updated fingerprint for {song_name} in DB.")

if __name__ == "__main__":
    import sys
    if len(sys.argv) != 2:
        print("Usage: python generate_fingerprint_json.py <path_to_audio.wav>")
    else:
        generate_fingerprint_json(sys.argv[1])
