from flask import Flask, request, jsonify
from process_temp_audio import process_file
import os
from werkzeug.utils import secure_filename

app = Flask(__name__)
TEMP_DIR = r"C:\Users\ishit\Audiora01\backend\temp"

@app.route('/match-audio', methods=['POST'])
def match_audio():
    if 'file' not in request.files:
        return jsonify({"status": "error", "message": "No file uploaded"}), 400

    file = request.files['file']
    if file.filename == '':
        return jsonify({"status": "error", "message": "Empty filename"}), 400

    filename = secure_filename(file.filename)
    file_path = os.path.join(TEMP_DIR, filename)
    file.save(file_path)

    print(f"🎧 Received file: {file_path}")
    result = process_file(file_path)

    os.remove(file_path)
    print(f"🗑️ Deleted temp file: {file_path}")

    return jsonify(result)

if __name__ == "__main__":
    app.run(port=5000)
