import os
import hashlib
from pymongo import MongoClient
from utils import fingerprint_audio

TEMP_FOLDER = r"C:\Users\ishit\Audiora01\temp"

def fingerprint_to_sha256(file_path):
    hashes = fingerprint_audio(file_path)
    fingerprint_str = ",".join(map(str, hashes))
    return hashlib.sha256(fingerprint_str.encode()).hexdigest()

def find_match_in_db(fingerprint_hash):
    client = MongoClient("mongodb://localhost:27017")
    db = client["audiodb"]
    collection = db["fingerprints"]
    return collection.find_one({"fingerprint": fingerprint_hash})

def process_file():
    files = [f for f in os.listdir(TEMP_FOLDER) if f.lower().endswith(".wav")]

    if not files:
        print(f"No WAV files found in {TEMP_FOLDER}")
        return

    for file in files:
        full_path = os.path.join(TEMP_FOLDER, file)
        print(f"Processing temp file: {file}")
        fingerprint_hash = fingerprint_to_sha256(full_path)
        print(f"Fingerprint SHA256: {fingerprint_hash}")

        match = find_match_in_db(fingerprint_hash)
    
        # ✅ Clean up before returning
        os.remove(full_path)
        print(f"Removed temp file: {file}")

        if match:
            return {"match": True, "song_name": match['song_name']}
        else:
            return {"match": False, "song_name": None}

if __name__ == "__main__":
    process_file()
