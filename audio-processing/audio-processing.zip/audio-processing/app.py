import os
import hashlib
from utils import convert_mp3_to_wav, fingerprint_audio
from pymongo import MongoClient
from pydub import AudioSegment

SONGS_FOLDER = r"C:\Users\ishit\Audiora01\songs"

def fingerprint_song(file_path):
    # Convert mp3 to wav
    wav_path = convert_mp3_to_wav(file_path)
    
    # Fingerprint wav
    hashes = fingerprint_audio(wav_path)
    fingerprint_str = ",".join(map(str, hashes))
    fingerprint_hash = hashlib.sha256(fingerprint_str.encode()).hexdigest()
    
    # Get song info
    song_name = os.path.basename(file_path)
    audio = AudioSegment.from_file(file_path)
    duration = round(len(audio) / 1000, 2)

    return {
        "song_name": song_name,
        "fingerprint": fingerprint_hash,
        "duration": duration
    }

def main():
    client = MongoClient("mongodb://localhost:27017")
    db = client["audiodb"]
    collection = db["fingerprints"]

    files = [f for f in os.listdir(SONGS_FOLDER) if f.lower().endswith(".mp3")]

    for file in files:
        song_name = file
        # Check if song already in DB
        if collection.find_one({"song_name": song_name}):
            print(f"Skipping already processed: {song_name}")
            continue

        try:
            file_path = os.path.join(SONGS_FOLDER, file)
            data = fingerprint_song(file_path)
            collection.insert_one(data)
            print(f"Inserted fingerprint for: {song_name}")
        except Exception as e:
            print(f"Error processing {song_name}: {e}")

if __name__ == "__main__":
    main()
